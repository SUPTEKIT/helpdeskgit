<?php

define("USER", "root");
define("SERVER", "localhost");
define("BD", "ticket");
define("PASS", "");
?>